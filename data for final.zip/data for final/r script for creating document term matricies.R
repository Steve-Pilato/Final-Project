############# Import libraries ############# 
library(readr) #Read in csv files
library(quanteda) #For creating document term-frequency matrix
library(dplyr) #FOr piping operator


############# Import postprocessed data (python post processed data.csv) ############# 
path <- ''
preprocessed_df <- read_csv(path) #Read in preprocessed data from Python

############# Create dfm ############# 
colnames(preprocessed_df) = c('label', 'text') # These column names are needed for using corpus function

#Create corpus object and matrix
dfm <- corpus(preprocessed_df) %>%
  dfm(corpus, tolower = F)
out_path_with_stop_words <- ''
write.csv(dfm, out_path_with_stop_words) #Output dfm


######## Create a document term- frequency matrix with no Stop words ######## 
#Create corpus object and matrix
dfm_no_stop <- corpus(preprocessed_df) %>%
  dfm(remove = stopwords('english'))
out_path_without_stop_words <- ''
write.csv(dfm_no_stop, out_path_without_stop_words) #Output dfm





